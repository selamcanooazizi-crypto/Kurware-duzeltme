KurWare 1.1.0 (kaynak) - MaceElytraTarget + Freelook
GitHub'a yukle -> Actions sekmesi -> "Build KurWare" -> Artifacts -> KurWare-jar
