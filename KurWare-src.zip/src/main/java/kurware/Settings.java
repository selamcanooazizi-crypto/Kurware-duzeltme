package kurware;

public class Settings {
    public static boolean enabled = false;
    public static boolean players = true;
    public static boolean mobs = false;
    public static boolean silent = false;
    /** true: kamera oynamaz, rotasyon sadece sunucuya gider (F5'te model hedefe bakar). */
    public static boolean freelook = true;
    public static int chestSpeed = 15;
    public static int fireworkSpeed = 20;
}
