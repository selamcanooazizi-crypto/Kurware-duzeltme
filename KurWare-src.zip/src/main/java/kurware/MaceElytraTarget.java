package kurware;

import java.util.function.Predicate;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class MaceElytraTarget {
    enum State { FLY, TO_CHEST, ATTACK }

    static State state = State.FLY;
    static int wait = 0;
    static int fwWait = 0;

    // Freelook durumu
    static boolean rotated = false;
    static float savedYaw, savedPitch, aimYaw;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null
                || !Settings.enabled || mc.currentScreen != null) {
            state = State.FLY;
            wait = 0;
            return;
        }

        LivingEntity target = findTarget(mc, p);
        if (target == null) {
            state = State.FLY;
            return;
        }

        PlayerInventory inv = p.getInventory();
        int maceSlot = find(inv, 0, 8, s -> s.isOf(Items.MACE) && (!Settings.silent || hasWindBurst(s)));
        int rocketSlot = find(inv, 0, 8, s -> s.isOf(Items.FIREWORK_ROCKET));
        int elytraSlot = find(inv, 0, 35, s -> s.isOf(Items.ELYTRA) && s.getDamage() < s.getMaxDamage() - 1);
        int chestSlot = find(inv, 0, 35, s -> {
            Item it = s.getItem();
            return it instanceof ArmorItem a && a.getSlotType() == EquipmentSlot.CHEST;
        });
        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        boolean elytraWorn = chest.isOf(Items.ELYTRA);

        if (maceSlot < 0 || rocketSlot < 0 || (!elytraWorn && elytraSlot < 0)) return;

        aim(p, target);

        int chestDelay = Math.max(0, 25 - Settings.chestSpeed);
        int fwDelay = Math.max(0, 40 - Settings.fireworkSpeed);

        if (wait > 0) {
            wait--;
            return;
        }

        switch (state) {
            case FLY -> {
                if (!elytraWorn) {
                    swapChest(mc, p, elytraSlot);
                    wait = chestDelay;
                    return;
                }
                if (p.isOnGround()) {
                    mc.options.jumpKey.setPressed(true);
                    return;
                }
                mc.options.jumpKey.setPressed(false);
                if (!p.isFallFlying()) {
                    // Creative: uçuş modundayken elytra açılamıyor -> önce uçuşu kapat
                    if (p.getAbilities().flying) {
                        p.getAbilities().flying = false;
                        p.sendAbilitiesUpdate();
                        return;
                    }
                    if (p.getVelocity().y < 0.0) {
                        p.networkHandler.sendPacket(new ClientCommandC2SPacket(p,
                                ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                        p.startFallFlying();
                    }
                    return;
                }
                if (distance(p, target) <= 5.0) {
                    state = State.TO_CHEST;
                    return;
                }
                if (fwWait-- <= 0) {
                    withSlot(mc, rocketSlot, () -> mc.interactionManager.interactItem(p, Hand.MAIN_HAND));
                    fwWait = fwDelay;
                }
            }
            case TO_CHEST -> {
                if (elytraWorn && chestSlot >= 0) {
                    swapChest(mc, p, chestSlot);
                    wait = chestDelay;
                }
                state = State.ATTACK;
            }
            case ATTACK -> {
                double d = distance(p, target);
                if (d <= 3.0) {
                    withSlot(mc, maceSlot, () -> {
                        mc.interactionManager.attackEntity(p, target);
                        p.swingHand(Hand.MAIN_HAND);
                    });
                    state = State.FLY;
                    fwWait = 0;
                } else if (d > 9.0) {
                    state = State.FLY;
                }
            }
        }
    }

    /** Tick sonunda kamerayı geri verir (Freelook). Sunucuya giden rotasyon hedefte kalır. */
    public static void restore(MinecraftClient mc) {
        if (!rotated) return;
        rotated = false;
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        p.setYaw(savedYaw);
        p.setPitch(savedPitch);
        p.prevYaw = savedYaw;
        p.prevPitch = savedPitch;
        // F5'te model hedefe baksın
        p.bodyYaw = aimYaw;
        p.prevBodyYaw = aimYaw;
        p.headYaw = aimYaw;
        p.prevHeadYaw = aimYaw;
    }

    static LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestDist = 4096.0;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le == p) continue;
            if (!le.isAlive()) continue;
            boolean ok = (Settings.players && le instanceof PlayerEntity pl && !pl.isSpectator())
                    || (Settings.mobs && le instanceof MobEntity);
            if (!ok) continue;
            double d = p.squaredDistanceTo(le);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    static void aim(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Vec3d to = t.getPos().add(0.0, t.getHeight() * 0.5, 0.0);
        Vec3d d = to.subtract(eye);
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z)));
        if (Settings.freelook && !rotated) {
            savedYaw = p.getYaw();
            savedPitch = p.getPitch();
            rotated = true;
        }
        aimYaw = yaw;
        p.setYaw(yaw);
        p.setPitch(pitch);
    }

    static double distance(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Box b = t.getBoundingBox();
        return eye.distanceTo(new Vec3d(
                MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY, b.maxY),
                MathHelper.clamp(eye.z, b.minZ, b.maxZ)));
    }

    static boolean hasWindBurst(ItemStack s) {
        for (RegistryEntry<Enchantment> e : s.getEnchantments().getEnchantments()) {
            if (e.matchesKey(Enchantments.WIND_BURST)) return true;
        }
        return false;
    }

    static int find(PlayerInventory inv, int from, int to, Predicate<ItemStack> pred) {
        for (int i = from; i <= to; i++) {
            if (pred.test(inv.getStack(i))) return i;
        }
        return -1;
    }

    static void swapChest(MinecraftClient mc, ClientPlayerEntity p, int slot) {
        if (slot < 0) return;
        int id = p.playerScreenHandler.syncId;
        if (slot < 9) {
            mc.interactionManager.clickSlot(id, 6, slot, SlotActionType.SWAP, p);
        } else {
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(id, 6, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p);
        }
    }

    static void withSlot(MinecraftClient mc, int slot, Runnable r) {
        ClientPlayerEntity p = mc.player;
        PlayerInventory inv = p.getInventory();
        int prev = inv.selectedSlot;
        if (prev != slot) {
            inv.selectedSlot = slot;
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
        r.run();
        if (Settings.silent && prev != slot) {
            inv.selectedSlot = prev;
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(prev));
        }
    }
}
