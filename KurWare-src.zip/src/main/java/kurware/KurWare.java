package kurware;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class KurWare implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kurware.menu", InputUtil.Type.KEYSYM, 344, "category.kurware"));
        ClientTickEvents.START_CLIENT_TICK.register(KurWare::onStartTick);
        ClientTickEvents.END_CLIENT_TICK.register(MaceElytraTarget::restore);
    }

    private static void onStartTick(MinecraftClient mc) {
        if (menuKey.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new KurGui());
            }
        } else {
            MaceElytraTarget.tick(mc);
        }
    }
}
